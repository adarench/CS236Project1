#include "expression.h"

void Expression::SetRight(const Parameter& right) {
    rightParam = right;
}

void Expression::SetOperator(const Parameter& oper) {
    Operator = oper;
}

void Expression::SetLeft(const Parameter& left) {
    leftParam = left;
}

string Expression::GetExpression() const {
    stringstream ss;
    ss << rightParam.ToString() << Operator.ToString() << leftParam.ToString();
    return ss.str();
}

string Expression::ToString() const {
    stringstream ss;
    ss << "(" << rightParam.ToString() << Operator.ToString() << leftParam.ToString() << ")";
    return ss.str();
}
