#include "predicate.h"
#include <sstream>

void Predicate::SetName(const string& theName) {
    Name = theName;
}

void Predicate::PushPredicate(const Parameter& theParameter) {
    parameterList.push_back(theParameter);
}

string Predicate::ToString() const {
    stringstream ss;
    ss << Name << "(";
    bool first = true;
    for (const auto& param : parameterList) {
        if (first) {
            first = false;
        } else {
            ss << ",";
        }
        ss << param.ToString();
    }
    ss << ")";
    return ss.str();
}

const vector<Parameter>& Predicate::ReturnVector() const {
    return parameterList;
}
