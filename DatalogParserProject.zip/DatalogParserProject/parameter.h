//
// Created by Adam Rencher on 2/21/23.
//

#ifndef DATALOGPARSERPROJECT_PARAMETER_H
#define DATALOGPARSERPROJECT_PARAMETER_H

class Parameter {
private:
    string currentParameter;
public:
    void setParameter(string currentParameter);
};
#endif //DATALOGPARSERPROJECT_PARAMETER_H
