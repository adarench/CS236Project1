//
// Created by Adam Rencher on 2/21/23.
//


#include "parameter.h"

void Parameter::SetParam(string Toke){
    theParameter = Toke;
}

string Parameter::ToString(){
    return theParameter;
}

