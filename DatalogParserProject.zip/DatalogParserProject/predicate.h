#ifndef DATALOGPARSERPROJECT_PREDICATE_H
#define DATALOGPARSERPROJECT_PREDICATE_H

#pragma once
#include "parameter.h"
#include <vector>

class Predicate {
public:
    void SetName(const string& theName);
    const vector<Parameter>& ReturnVector() const;
    void PushPredicate(const Parameter& theParameter);
    string ToString() const;
private:
    vector<Parameter> parameterList;
    string Name;
};
#endif //DATALOGPARSERPROJECT_PREDICATE_H