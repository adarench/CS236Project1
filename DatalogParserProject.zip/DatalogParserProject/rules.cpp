//
// Created by Adam Rencher on 2/21/23.
//


#include "rules.h"


void Rule::SetHeadPredicate( const Predicate head) {
    Head = head;
}

void Rule::SetRule(const vector<Predicate>& Toke) {
    RuleList.reserve(Toke.size());
    for (const auto& predicate : Toke) {
        RuleList.push_back(predicate);
    }
}


string Rule::ToString() {
    stringstream ss;
    ss << Head.ToString() << " :- ";
    bool isFirst = true;
    for (const auto& predicate : RuleList) {
        if (!isFirst) {
            ss << ",";
        }
        ss << predicate.ToString();
        isFirst = false;
    }
    ss << ".";
    return ss.str();
}
