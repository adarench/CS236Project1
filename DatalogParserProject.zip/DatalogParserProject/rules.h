//
// Created by Adam Rencher on 2/21/23.
//

#ifndef DATALOGPARSERPROJECT_RULES_H
#define DATALOGPARSERPROJECT_RULES_H


#pragma once
#include "predicate.h"

class Rule {
public:
    void SetHeadPredicate(Predicate head);
    void SetRule(vector<Predicate> Toke);
    string ToString();
private:
    Predicate Head;
    vector<Predicate> RuleList;
};

#endif //DATALOGPARSERPROJECT_RULES_H
