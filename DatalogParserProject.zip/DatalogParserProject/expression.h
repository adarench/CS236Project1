#ifndef DATALOGPARSERPROJECT_EXPRESSION_H
#define DATALOGPARSERPROJECT_EXPRESSION_H

#include "token.h"
#include "parameter.h"
#include <vector>
#include <sstream>

class Expression {
public:
    void SetRight(const Parameter& right);
    void SetOperator(const Parameter& oper);
    void SetLeft(const Parameter& left);
    string GetExpression() const;
    string ToString() const;
private:
    Parameter rightParam;
    Parameter Operator;
    Parameter leftParam;
};

#endif //DATALOGPARSERPROJECT_EXPRESSION_H
