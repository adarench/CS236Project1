#include "parser.h"
#include "token.h"
using namespace std;

int main() {
    vector<Token> tokens;
    tokens.push_back(Token(ID,"Ned",2));
    tokens.push_back(Token(LEFT_PAREN,"(",2));
    tokens.push_back(Token(RIGHT_PAREN,")",2));

    Parser p = Parser(tokens);
    p.match(ID);
    p.match(LEFT_PAREN);
    p.match(RIGHT_PAREN);

    Parser p2 = Parser(tokens);
    cout << p2.tokenType() << endl;
    p2.advanceToken();
    cout << p2.tokenType() << endl;
    p2.advanceToken();
    cout << p2.tokenType() << endl;
    p2.throwError();

    Parser p = Parser(tokens);
    p.idList();

    Parser p = Parser(tokens);
    p.scheme();
}
//
// Created by Adam Rencher on 2/20/23.
//

