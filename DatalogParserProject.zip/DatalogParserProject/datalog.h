#pragma once

#include <set>
#include "rules.h"

class Datalog {
public:
    void SetFacts(const vector<Predicate>& facts);
    void SetQueries(const vector<Predicate>& queries);
    void SetSchemes(const vector<Predicate>& schemes);
    void SetRules(const vector<Rule>& rules);
    vector<Rule> GetRules() const;
    vector<Predicate> GetQueries() const;
    vector<Predicate> GetFacts() const;
    vector<Predicate> GetSchemes() const;
    void SetDomain(const set<string>& domain);
    string ToString() const;
private:
    vector<Rule> rules;
    vector<Predicate> facts;
    vector<Predicate> queries;
    vector<Predicate> schemes;
    set<string> domain;
};
