#include "datalog.h"
#include <sstream>

void Datalog::SetFacts(const vector<Predicate>& facts) {
    Facts = facts;
}

void Datalog::SetQueries(const vector<Predicate>& queries) {
    Queries = queries;
}

void Datalog::SetSchemes(const vector<Predicate>& schemes) {
    Schemes = schemes;
}

void Datalog::SetRules(const vector<Rule>& rules) {Rules = rules;
}

vector<Rule> Datalog::GetRules() const {
    return Rules;
}

vector<Predicate> Datalog::GetQueries() const {
    return Queries;
}

vector<Predicate> Datalog::GetFacts() const {
    return Facts;
}

vector<Predicate> Datalog::GetSchemes() const {
    return Schemes;
}

void Datalog::SetDomain(const set<string>& domain) {
    Domain = domain;
}

string Datalog::ToString() const {
    stringstream ss;
    ss << "Schemes(" << Schemes.size() << "):\n";
    for (const auto& scheme : Schemes) {
        ss << "  " << scheme.toString() << "\n";
    }

    ss << "Facts(" << Facts.size() << "):\n";
    for (const auto& fact : Facts) {
        ss << "  " << fact.toString() << ".\n";
    }

    ss << "Rules(" << Rules.size() << "):\n";
    for (const auto& rule : Rules) {
        ss << "  " << rule.toString() << "\n";
    }

    ss << "Queries(" << Queries.size() << "):\n";
    for (const auto& query : Queries) {
        ss << "  " << query.toString() << "?\n";
    }

    ss << "Domain(" << Domain.size() << "):\n";
    for (const auto& element : Domain) {
        ss << "  " << element << "\n";
    }

    return ss.str();
}
